import java.util.*;

public class Translator {
    ArrayList<String> vmInstructions;
    ArrayList<String> asmInstructions;
    String fileName;
    int counter = 0;


    public Translator(ArrayList<String> vmInstructions, String fileName){
        this.vmInstructions = vmInstructions;
        this.fileName = fileName;
        this.asmInstructions = new ArrayList<>();

        for(String instruction : this.vmInstructions){
            this.asmInstructions.add("// "+instruction);
            if(instruction.startsWith("p")){
                this.writePushPop(instruction);
            } else {
                this.writeArithmetic(instruction);
            }
        }
    }

    public void writeArithmetic(String arithmeticInstruction){
        switch (arithmeticInstruction){
            case "add":
                ArrayList<String> add = new ArrayList<>(Arrays.asList("@SP", "AM=M-1", "D=M", "A=A-1", "M=D+M"));
                this.asmInstructions.addAll(add);
                break;

            case "sub":
                ArrayList<String> sub = new ArrayList<>(Arrays.asList("@SP", "AM=M-1", "D=M", "A=A-1", "M=M-D"));
                this.asmInstructions.addAll(sub);
                break;

            case "eq":
                ArrayList<String> eq = new ArrayList<>(
                        Arrays.asList("@SP", "AM=M-1", "D=M", "A=A-1", "D=M-D",  // x-y
                                "@SET_TRUE_" + counter , "D;JEQ",   // if value is 0, set to true (-1)
                                "@SP", "A=M-1","M=0", "@END_" + counter, "0;JMP", // if not, sent to 0 (false)
                                "(SET_TRUE_" + counter + ")","@SP", "A=M-1", "M=-1", "@END_"+ counter, "0;JMP",
                                "(END_"+ counter+ ")"
                        ));
                counter++;
                this.asmInstructions.addAll(eq);
                break;

            case "lt":
                ArrayList<String> lt = new ArrayList<>(
                        Arrays.asList("@SP", "AM=M-1", "D=M", "A=A-1", "D=M-D",
                                "@SET_TRUE_" + counter , "D;JLT",
                                "@SP", "A=M-1","M=0", "@END_" + counter, "0;JMP",
                                "(SET_TRUE_" + counter + ")", "@SP", "A=M-1","M=-1", "@END_"+ counter, "0;JMP",
                                "(END_"+ counter+ ")"
                        ));
                counter++;
                this.asmInstructions.addAll(lt);
                break;

            case "gt":
                ArrayList<String> gt = new ArrayList<>(
                        Arrays.asList("@SP", "AM=M-1", "D=M", "A=A-1", "D=M-D",
                                "@SET_TRUE_" + counter , "D;JGT",
                                "@SP", "A=M-1","M=0", "@END_" + counter, "0;JMP",
                                "(SET_TRUE_" + counter + ")", "@SP", "A=M-1", "M=-1", "@END_" + counter, "0;JMP",
                                "(END_"+ counter+ ")"
                        ));
                counter++;
                this.asmInstructions.addAll(gt);
                break;

            case "neg":
                ArrayList<String> neg = new ArrayList<>(
                        Arrays.asList("@SP", "A=M-1", "D=M", "@0", "D=A-D", "@SP", "A=M-1", "M=D"));
                this.asmInstructions.addAll(neg);
                break;

            case "and":
                ArrayList<String> and = new ArrayList<>(Arrays.asList(
                        "@SP", "AM=M-1", "D=M", "A=A-1", "D=D&M", "M=D"
                        ));
                this.asmInstructions.addAll(and);
                break;

            case "or":
                ArrayList<String> or = new ArrayList<>(Arrays.asList(
                        "@SP", "AM=M-1", "D=M", "A=A-1", "D=D|M", "M=D"
                ));
                this.asmInstructions.addAll(or);
                break;

            case "not":
                ArrayList<String> not = new ArrayList<>(Arrays.asList(
                        "@SP", "A=M-1", "D=M", "M=!D"
                ));
                this.asmInstructions.addAll(not);
                break;
        }
    }

    public void writePushPop(String pushPopInstruction){
        // System.out.println("Push/pop inst: " + pushPopInstruction);
        String[] instArr= pushPopInstruction.split(" ");
        String seg = instArr[1];
        int val = Integer.parseInt(instArr[2]);

        if(pushPopInstruction.startsWith("push")){
            this.translatePush(seg, val);
        } else {
            this.translatePop(seg, val);
        }
    }

    public void translatePush(String segment, int value){
        ArrayList<String> pushInst = new ArrayList<>();

        String index = "@" + value;
        List<String> assign = Arrays.asList("D=M",index,"A=D+A", "D=M");

        switch (segment){
            case "constant":
                Collections.addAll(pushInst,index, "D=A");
                break;

            case "local":
                pushInst.add("@LCL");
                pushInst.addAll(assign);
                break;

            case "temp":
                String tempIndex = "@"+(5+value);
                pushInst.add(tempIndex);
                pushInst.add("D=M");
                break;

            case "argument":
                pushInst.add("@ARG");
                pushInst.addAll(assign);
                break;

            case "this":
                pushInst.add("@THIS");
                pushInst.addAll(assign);
                break;

            case "that":
                pushInst.add("@THAT");
                pushInst.addAll(assign);
                break;

            case "pointer":
                if(value == 0){
                    Collections.addAll(pushInst, "@THIS", "D=M");
                } else if (value == 1) {
                    Collections.addAll(pushInst, "@THAT", "D=M");
                }
                else {
                    throw new Error("pointer can only reference values 0 or 1");
                }
                break;

            case "static":
                String staticName = "@"+fileName + "." + value;
                Collections.addAll(pushInst, staticName, "D=M");
                break;

        }
        Collections.addAll(pushInst,"@SP", "AM=M+1", "A=A-1", "M=D");

        this.asmInstructions.addAll(pushInst);
        // System.out.println("ASM: " + pushInst);
    }
    public void translatePop(String segment, int value){
        // System.out.println("seg: " + segment + "\nval: "+value);
        ArrayList<String> popInst = new ArrayList<>();
        String index = "@" + value;

        if(!segment.equals("temp") && !segment.equals("pointer") && !segment.equals("static")){
            Collections.addAll(popInst,index, "D=A");
        }
        // store pop destination address in tmp R13
        List<String> assign = Arrays.asList("D=D+M", "@R13", "M=D");

        switch (segment){

            case "local":
                popInst.add("@LCL");
                popInst.addAll(assign);
                break;

            case "temp":
                String tempIndex = "@"+(5+value);
                Collections.addAll(popInst, "@SP", "AM=M-1","D=M");
                popInst.add(tempIndex);
                popInst.add("M=D");
                break;

            case "argument":
                popInst.add("@ARG");
                popInst.addAll(assign);
                break;

            case "this":
                popInst.add("@THIS");
                popInst.addAll(assign);
                break;

            case "that":
                popInst.add("@THAT");
                popInst.addAll(assign);
                break;

            case "pointer":
                // 0 is THIS, 1 is THAT
                if(value == 0){
                    Collections.addAll(popInst,"@SP", "AM=M-1","D=M","@THIS", "M=D");
                } else if (value == 1) {
                    Collections.addAll(popInst,"@SP", "AM=M-1","D=M","@THAT", "M=D");
                }
                else {
                    throw new Error("pointer can only reference values 0 or 1");
                }
                break;

            case "static":
                String staticName = "@"+fileName + "." + value;
                Collections.addAll(popInst,"@SP", "AM=M-1","D=M", staticName , "M=D");
                break;
        }

        if(!segment.equals("temp") && !segment.equals("pointer") && !segment.equals("static")) {
            Collections.addAll(popInst, "@SP", "AM=M-1", "D=M", "@R13", "A=M", "M=D");
        }

        this.asmInstructions.addAll(popInst);

        // System.out.println("ASM: " + popInst);
    }
}
